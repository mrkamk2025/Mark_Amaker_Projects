# SQL Projects

Examples of data analysis and reporting using SQL:
- Data extraction and transformation
- Analytical queries
- Reporting and business intelligence
- Data modeling

Project folders contain scripts, query files, and explanations.
