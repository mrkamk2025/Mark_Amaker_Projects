# SQL Sample Project: Sales Data Analysis

This project uses SQL to analyze company sales data and generate business insights.

## Highlights
- Data cleaning & transformation
- Aggregate and analytical queries
- Reporting: top products, monthly trends

## Files
- `sales_queries.sql`: Query scripts
- `sales_data.csv`: Sample dataset (see datasets folder)

## Tools Used
- MySQL / PostgreSQL

## Results
Identified top-performing products and seasonal trends.