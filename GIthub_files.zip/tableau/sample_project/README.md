# Tableau Sample Project: Executive Sales Dashboard

This project presents sales KPIs and trends in an interactive Tableau dashboard.

## Highlights
- Data preparation and blending
- KPI tracking
- Visual storytelling
- Interactive filters and drill-downs

## Files
- `dashboard.twbx`: Tableau workbook
- `sales_data.csv`: Sample dataset (see datasets folder)
- `screenshots/`: Dashboard images

## Results
Enabled executives to quickly monitor sales performance and identify opportunities.