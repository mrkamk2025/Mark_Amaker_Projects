# Python Sample Project: Customer Churn Prediction

This project demonstrates predictive analytics using Python to identify customers likely to churn.

## Highlights
- Data preprocessing with pandas
- Exploratory Data Analysis (EDA)
- Feature engineering
- Machine learning model (Random Forest)
- Visualization with matplotlib & seaborn

## Files
- `churn_analysis.ipynb`: Main analysis notebook
- `data.csv`: Sample dataset (see datasets folder)
- `images/`: Plots and figures

## Tools Used
- pandas, numpy, scikit-learn, seaborn, matplotlib

## Results
Achieved >80% accuracy in predicting customer churn.