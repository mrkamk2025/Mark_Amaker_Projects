# Datasets

Sample datasets used across my projects. Each dataset includes:
- Source information
- Data dictionary
- License (if applicable)

Raw data files or links provided.
