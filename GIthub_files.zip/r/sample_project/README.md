# R Sample Project: Marketing Campaign Effectiveness

This project evaluates the effectiveness of marketing campaigns using R.

## Highlights
- Data import and transformation
- Statistical analysis (t-tests, regression)
- Visualization with ggplot2

## Files
- `campaign_analysis.R`: Main script
- `marketing_data.csv`: Sample dataset (see datasets folder)
- `plots/`: Visualizations

## Tools Used
- R, ggplot2, dplyr

## Results
Provided actionable insights to improve future campaigns.