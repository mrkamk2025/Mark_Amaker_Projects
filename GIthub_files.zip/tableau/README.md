# Tableau Projects

Interactive dashboards and visual analytics:
- Business intelligence dashboards
- Storytelling with data
- KPI tracking

Links to Tableau Public or screenshots/charts included.
