# R Projects

Projects leveraging R for statistics and visualization:
- Statistical analysis
- Data modeling
- Visualization (ggplot2, Shiny dashboards)

Each folder includes R scripts and project documentation.
